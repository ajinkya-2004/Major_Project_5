import logoNoBackground from "./logo-no-background.svg";
import logoBlack from "./logo-black.svg";
import logoColor from "./logo-color.svg";
import logoWhite from "./logo-white.svg";
import logoCollapsed from "./logo-collapsed.svg";

export { logoBlack, logoColor, logoWhite, logoNoBackground, logoCollapsed, };